package com.hibtest1;

import org.hibernate.Session;
import org.hibernate.Transaction;
import com.hibtest1.entity.Users;

public class TestDelete {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new TestDelete().testDelete();
	}
	
	private void testDelete(){
		//���Sessionʵ��
	    Session session=HibernateSessionFactory.getSession();
		Transaction tx=null;
		//����Ҫɾ��������
		Users user=(Users)session.get(Users.class, 1);
		try {
			tx=session.beginTransaction();    //��ʼһ������			
			session.delete(user);             //ִ��ɾ��	
			tx.commit();                      //�ύ����
		} catch (Exception e) {
			if(tx!=null){
				tx.rollback();       //����ع�				
			}
			e.printStackTrace();
		}finally{
			HibernateSessionFactory.closeSession();   //�ر�session
		}
	}
}
