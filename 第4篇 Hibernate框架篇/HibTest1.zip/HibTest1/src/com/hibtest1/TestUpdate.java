package com.hibtest1;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.hibtest1.entity.Users;

public class TestUpdate {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new TestUpdate().testUpdate();
	}
	
	private void testUpdate(){
		//���Sessionʵ��
	    Session session=HibernateSessionFactory.getSession();
		Transaction tx=null;
		//����Ҫ�޸ĵ�����
		Users user=(Users)session.get(Users.class, new Integer(2));
		//�޸�����
		user.setLoginName("popopo");
		try {
			tx=session.beginTransaction();    //��ʼһ������			
			session.update(user);             //ִ�и���
			tx.commit();                      //�ύ����
		} catch (Exception e) {
			if(tx!=null){
				tx.rollback();       //����ع�				
			}
			e.printStackTrace();
		}finally{
			HibernateSessionFactory.closeSession();   //�ر�session
		}
	}
}